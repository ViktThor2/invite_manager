
  <?php if(session('message')): ?>
      <div class="row mb-2">
          <div class="col-lg-12">
              <div class="alert alert-success" role="alert d-flex justify-content-center">
                <?php echo e(session('message')); ?>

              </div>
          </div>
      </div>
  <?php endif; ?>

  <?php if(session('error')): ?>
      <div class="alert alert-danger d-flex justify-content-center">
            <?php echo e(session('error')); ?>

      </div>
  <?php endif; ?>
<?php /**PATH /opt/lampp/htdocs/laravel-ingatlan/resources/views/layout/message.blade.php ENDPATH**/ ?>