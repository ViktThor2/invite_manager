<!DOCTYPE html>
<html>

  <head>
      <title>Ingatlankezelő</title>

      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>


  </head>

  <body>

    <?php $email = \Hash::make($request->email); ?>
    Regisztráció : http://127.0.0.1:8000/invite/create/<?php echo e($email); ?>


  </body>
</html>
<?php /**PATH /opt/lampp/htdocs/laravel-ingatlan/resources/views/admin/costumer_invite/email.blade.php ENDPATH**/ ?>