<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
      Felhasználók
    </div>

    <div class="card-body">

        <div class="d-flex justify-content-end">
          <?php echo $costumers->links(); ?>

        </div>

        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-User">

                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Név</th>
                        <th>Email cím</th>
                        <th width="200"></th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $costumers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $costumer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($costumer->id ?? ''); ?></td>
                            <td><?php echo e($costumer->name ?? ''); ?></td>
                            <td><?php echo e($costumer->email ?? ''); ?></td>

                            <td>
                                <form action="<?php echo e(route('costumer.destroy',$costumer->id)); ?>" method="POST">
                                  <a class="btn btn-sm btn-primary" href="<?php echo e(route('costumer.edit',$costumer->id)); ?>">Szerkesztés</a>
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('DELETE'); ?>
                                  <button type="submit" class="btn btn-sm btn-danger">Törlés</button>
                                </form>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>

        <div class="d-flex justify-content-end">
            <?php echo $costumers->links(); ?>

        </div>

    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/laravel-ingatlan/resources/views/admin/costumer/index.blade.php ENDPATH**/ ?>