<!DOCTYPE html>
<html>

  <head>
      <title>Ingatlankezelő</title>

      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <link href="{{ asset('css/admin.css') }}" rel="stylesheet">
      <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>


  </head>

  <body id="page-top">

    <div id="wrapper">
      @include('layout.left-nav')

      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">

          <!-- Main Content -->
          <div id="content">
            @include('layout.top-nav')

            @include('layout.message')

            @yield('content')
          </div>

          @include('layout.footer')
      </div>
      <!-- End of Content Wrapper -->

      @include('layout.logout')
    </div>

    <script src="{{ asset('js/admin.js') }}"></script>
  </body>
</html>
