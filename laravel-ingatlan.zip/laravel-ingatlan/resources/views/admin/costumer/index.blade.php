@extends('layout.app')
@section('content')

<div class="card">
    <div class="card-header">
      Felhasználók
    </div>

    <div class="card-body">

        <div class="d-flex justify-content-end">
          {!! $costumers->links() !!}
        </div>

        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-User">

                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Név</th>
                        <th>Email cím</th>
                        <th width="200"></th>
                    </tr>
                </thead>

                <tbody>
                    @foreach($costumers as $costumer)
                            <td>{{ $costumer->id ?? '' }}</td>
                            <td>{{ $costumer->name ?? '' }}</td>
                            <td>{{ $costumer->email ?? '' }}</td>

                            <td>
                                <form action="{{ route('costumer.destroy',$costumer->id) }}" method="POST">
                                  <a class="btn btn-sm btn-primary" href="{{ route('costumer.edit',$costumer->id) }}">Szerkesztés</a>
                                  @csrf
                                  @method('DELETE')
                                  <button type="submit" class="btn btn-sm btn-danger">Törlés</button>
                                </form>
                            </td>

                        </tr>
                    @endforeach
                </tbody>

            </table>
        </div>

        <div class="d-flex justify-content-end">
            {!! $costumers->links() !!}
        </div>

    </div>
</div>



@endsection
