<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Costumer extends Model
{
    use HasFactory;

    public function setData($request)
    {
      $this->name = $request['name'];
      $this->email = $request['email'];
      $this->password = $request['password'];
      $this->active = 1;
    }

    public function scopeCheck($query, $data)
    {
        $query->where('email', 'LIKE', '%' . $data . '%');
    }

}
